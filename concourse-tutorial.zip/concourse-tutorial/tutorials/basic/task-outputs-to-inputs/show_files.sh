#!/bin/sh

ls some-files/*
