#!/bin/sh

uname -a
